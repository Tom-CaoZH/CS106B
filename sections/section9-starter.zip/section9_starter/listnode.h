#pragma once
#include <string>

struct ListNode {
    int data;
    ListNode *next;
};
